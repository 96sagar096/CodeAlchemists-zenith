import { Link, useParams } from "react-router-dom"
import Navbar from "../components/Navbar"
import { getComplaints } from "../data/mockData"
import { useEffect ,useState } from "react"
import { API_URL } from "../api/api";




function ComplaintDetails() {

  const { id } = useParams()
 
  const [complaint, setComplaint] = useState(null);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem("token");
  const[proof , setProof] = useState(null);
  
 
 useEffect(() => {
  async function fetchData() {
    try {
      
      const response = await fetch(
        `${API_URL}/api/complaint/my/${id}`,{
          method: "GET",
           headers: {
            "Authorization": `Bearer ${token}`
          }

        }
      );

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }

      const data = await response.json();

      console.log(data);

      setComplaint(data);

    } catch (error) {
      console.log("You have an error:", error);
    } finally {
      setLoading(false);
    }
  }

  fetchData();
}, [id]);

const getImage = async () => {
  try {
    const response = await fetch(
      `${API_URL}/api/complaint/${complaint.incidentId}/evidence` , {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${token}`
        }
      }
    )

    if(response.ok){
      const blob = await response.blob();
      const imageUrl = URL.createObjectURL(blob);
      setProof(imageUrl);

    }

  }catch (error) {
    console.log("Error fetching image :" , error);
  }
}
  if (loading) {
  return <div>Loading...</div>;
  }

  if (!complaint) {
    return (
      <div>
        <Navbar />

        <main className="max-w-4xl mx-auto p-6">
          <h1 className="text-2xl font-bold">
            Complaint not found
          </h1>

          <Link
            to="/history"
            className="text-blue-700 mt-4 inline-block"
          >
            Go back
          </Link>
        </main>
      </div>
    )
  }

  return (
    <div>

      <Navbar />

      <main className="max-w-5xl mx-auto p-6">

        <div className="flex justify-between items-center mb-6">

          <div>
            <p className="text-gray-500">
              Complaint #{complaint.incidentId}
            </p>

            <h1 className="text-3xl font-bold">
              {complaint.title}
            </h1>
          </div>

          <Link
            to="/history"
            className="border px-4 py-2 rounded-lg"
          >
            Back
          </Link>

        </div>

        <div className="grid md:grid-cols-3 gap-6">

          {/* Main complaint */}
          <div className="md:col-span-2 bg-white rounded-xl shadow p-6">

            <h2 className="text-xl font-bold mb-4">
              Complaint Description
            </h2>

            <p className="text-gray-700 leading-7">
              {complaint.description}
            </p>

            <div className="grid md:grid-cols-2 gap-4 mt-6">

             

              <div>
                <p className="text-sm text-gray-500">
                  Department
                </p>

                <p className="font-semibold">
                  {complaint.department}
                </p>
              </div>

              <div>
                <p className="text-sm text-gray-500">
                  Location
                </p>

                <p className="font-semibold">
                  {complaint.location}
                </p>
              </div>

              {/* <div>
                <p className="text-sm text-gray-500">
                  SubmittedAt
                </p>

                <p className="font-semibold">
                  {complaint.createdAt}
                </p>
              </div> */}

            </div>

          </div>

          {/* Status */}
          <div className="bg-white rounded-xl shadow p-6">

            <h2 className="text-xl font-bold mb-6">
              Status
            </h2>

            <div className="space-y-6">

              <div className="flex gap-3">
                <div className="w-4 h-4 rounded-full bg-green-500 mt-1" />

                <div>
                  <p className="font-semibold">
                    Submitted
                  </p>
                  <p className="text-sm text-gray-500">
                    Complaint received
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="w-4 h-4 rounded-full bg-green-500 mt-1" />

                <div>
                  <p className="font-semibold">
                    Assigned
                  </p>
                  <p className="text-sm text-gray-500">
                    Sent to department
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <div
                  className={`w-4 h-4 rounded-full mt-1 ${
                    complaint.status === "IN_PROGRESS" ||
                    complaint.status === "RESOLVED"
                      ? "bg-green-500"
                      : "bg-gray-300"
                  }`}
                />

                <div>
                  <p className="font-semibold">
                    In Progress
                  </p>
                  <p className="text-sm text-gray-500">
                    Department is working
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <div
                  className={`w-4 h-4 rounded-full mt-1 ${
                    complaint.status === "RESOLVED"
                      ? "bg-green-500"
                      : "bg-gray-300"
                  }`}
                />

                <div>
                  <p className="font-semibold">
                    Resolved
                  </p>
                  <p className="text-sm text-gray-500">
                    Complaint completed
                  </p>
                </div>
              </div>

            </div>

          </div>

        </div>

        <div className=" py-3 flex justify-center items-center ">
          <div className=" bg-cyan-200  rounded-2xl ">
            <button
          onClick={getImage}
          className="flex flex-col items-center  gap-3  p-3"
        >
          

          <span className="font-medium text-black">
            Proof of Work
          </span>
        </button>
            
          </div>
          {proof && (
            <img
              src={proof}
              alt="Resolution Evidence"
              className="w-100 py-3 h-100 object-contain rounded-lg border border-gray-300 shadow-md text-center"
            />
          )}
          

        </div>
     

        {/* AI information */}
        <div className="bg-blue-50 rounded-xl p-6 mt-6  ">


          <h2 className="text-xl font-bold mb-4">
            AI Analysis
          </h2>

         <div>
           <div className="grid grid-flow-row auto-rows-max m-2 py-3">
            <div>
              <p className="text-sm text-gray-500">
                Datetime
              </p>
              <p className="font-semibold">
                {complaint.dateTime}
              </p>
            </div>

            

            <div>
              <p className="text-sm text-gray-500">
                Department
              </p>
              <p className="font-semibold">
                {complaint.department}
              </p>
            </div>

            <div>
              <p className="text-sm text-gray-500">
                Severity
              </p>
              <p className="font-semibold">
                {complaint.severity}
              </p>
            </div>
             <div>
              <p className="text-sm text-gray-500">
                Description
              </p>
              <p className="font-semibold">
                {complaint.description}
              </p>
            </div>
             <div>
              <p className="text-sm text-gray-500">
                Location
              </p>
              <p className="font-semibold">
                {complaint.location}
              </p>
            </div>
             <div>
              <p className="text-sm text-gray-500">
                Status
              </p>
              <p className="font-semibold">
                {complaint.status}
              </p>
            </div>
         </div>

          </div>

        </div>

      </main>

    </div>
  )
}

//complaint = {
// id 
// title 
// description 
//category
//department
// location
// date
//priority }

export default ComplaintDetails